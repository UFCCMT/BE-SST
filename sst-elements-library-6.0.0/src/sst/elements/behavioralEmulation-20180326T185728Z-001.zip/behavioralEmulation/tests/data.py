lst = []
lst.append({})
lst[0]["rowmin"] = 0
lst[0]["rowmax"] = 0
lst[0]["colmin"] = 0
lst[0]["colmax"] = 0
lst[0]["planemin"] = 0
lst[0]["planemax"] = 0
lst[0]["Zminus"] = -4
lst[0]["Zplus"] = 4
lst[0]["Yminus"] = -2
lst[0]["Yplus"] = 2
lst[0]["Xminus"] = -1
lst[0]["Xplus"] = 1
lst[0]["recv1"] = 7
lst[0]["recv2"] = 7
lst[0]["recv3"] = 3

lst.append({})
lst[1]["rowmin"] = 0
lst[1]["rowmax"] = 1
lst[1]["colmin"] = 1
lst[1]["colmax"] = 0
lst[1]["planemin"] = 0
lst[1]["planemax"] = 1
lst[1]["Zminus"] = -3
lst[1]["Zplus"] = 5
lst[1]["Yminus"] = -1
lst[1]["Yplus"] = 3
lst[1]["Xminus"] = 0
lst[1]["Xplus"] = 2
lst[1]["recv1"] = 7
lst[1]["recv2"] = 6
lst[1]["recv3"] = 3

lst.append({})
lst[2]["rowmin"] = 1
lst[2]["rowmax"] = 0
lst[2]["colmin"] = 0
lst[2]["colmax"] = 1
lst[2]["planemin"] = 0
lst[2]["planemax"] = 1
lst[2]["Zminus"] = -2
lst[2]["Zplus"] = 6
lst[2]["Yminus"] = 0
lst[2]["Yplus"] = 4
lst[2]["Xminus"] = 1
lst[2]["Xplus"] = 3
lst[2]["recv1"] = 7
lst[2]["recv2"] = 5
lst[2]["recv3"] = 3

lst.append({})
lst[3]["rowmin"] = 1
lst[3]["rowmax"] = 0
lst[3]["colmin"] = 1
lst[3]["colmax"] = 0
lst[3]["planemin"] = 0
lst[3]["planemax"] = 1
lst[3]["Zminus"] = -1
lst[3]["Zplus"] = 7
lst[3]["Yminus"] = 1
lst[3]["Yplus"] = 5
lst[3]["Xminus"] = 2
lst[3]["Xplus"] = 4
lst[3]["recv1"] = 7
lst[3]["recv2"] = 4
lst[3]["recv3"] = 3

lst.append({})
lst[4]["rowmin"] = 0
lst[4]["rowmax"] = 1
lst[4]["colmin"] = 0
lst[4]["colmax"] = 1
lst[4]["planemin"] = 1
lst[4]["planemax"] = 0
lst[4]["Zminus"] = 0
lst[4]["Zplus"] = 8
lst[4]["Yminus"] = 2
lst[4]["Yplus"] = 6
lst[4]["Xminus"] = 3
lst[4]["Xplus"] = 5
lst[4]["recv1"] = 7
lst[4]["recv2"] = 3
lst[4]["recv3"] = 3

lst.append({})
lst[5]["rowmin"] = 0
lst[5]["rowmax"] = 1
lst[5]["colmin"] = 1
lst[5]["colmax"] = 0
lst[5]["planemin"] = 1
lst[5]["planemax"] = 0
lst[5]["Zminus"] = 1
lst[5]["Zplus"] = 9
lst[5]["Yminus"] = 3
lst[5]["Yplus"] = 7
lst[5]["Xminus"] = 4
lst[5]["Xplus"] = 6
lst[5]["recv1"] = 7
lst[5]["recv2"] = 2
lst[5]["recv3"] = 3


lst.append({})
lst[6]["rowmin"] = 1
lst[6]["rowmax"] = 0
lst[6]["colmin"] = 0
lst[6]["colmax"] = 1
lst[6]["planemin"] = 1
lst[6]["planemax"] = 0
lst[6]["Zminus"] = 2
lst[6]["Zplus"] = 10
lst[6]["Yminus"] = 4
lst[6]["Yplus"] = 8
lst[6]["Xminus"] = 5
lst[6]["Xplus"] = 7
lst[6]["recv1"] = 7
lst[6]["recv2"] = 1
lst[6]["recv3"] = 3


lst.append({})
lst[7]["rowmin"] = 1
lst[7]["rowmax"] = 0
lst[7]["colmin"] = 1
lst[7]["colmax"] = 0
lst[7]["planemin"] = 1
lst[7]["planemax"] = 0
lst[7]["Zminus"] = 3
lst[7]["Zplus"] = 11
lst[7]["Yminus"] = 5
lst[7]["Yplus"] = 9
lst[7]["Xminus"] = 6
lst[7]["Xplus"] = 8
lst[7]["recv1"] = 7
lst[7]["recv2"] = 0
lst[7]["recv3"] = 3

