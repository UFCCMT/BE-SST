#include <iostream>
using namespace std;
int main()
{
int a=1;
int b=1;
int c=11;
std::cout<<(a+b+c)<<"\n";
}
