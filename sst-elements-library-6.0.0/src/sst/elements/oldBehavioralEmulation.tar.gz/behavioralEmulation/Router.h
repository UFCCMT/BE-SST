#ifndef ROUTER_H
#define ROUTER_H

#include <vector>
#include <string>
#include <map>
#include "Layout.h"
namespace SST{
namespace BEComponent{

class Router{
public: 
    Router(Layout* l,  std::map<std::string, std::string> p){
        policies = p;
        layout = l;
    }

    std::vector<int> path(int src, int target);
    void clear();
	~Router(){}
private:
    std::vector<std::vector<int>> multiply (std::vector<std::vector<int>> a, int b);        
    std::vector<std::vector<int>> ident(int n, int x);
    std::vector<int> add(std::vector<int> a, std::vector<int> b);
    std::vector<int> sub(std::vector<int> a, std::vector<int> b);
    std::vector<int> torusAdd(std::vector<int> a, std::vector<int> b, std::vector<int> sizes);
    std::vector<int> torusSub(std::vector<int> a, std::vector<int> b, std::vector<int> sizes);
    std::vector<std::vector<std::vector<int>> > deltas(std::vector<int> a, std::vector<int> b); 
    std::vector<std::vector<std::vector<int>> > torusDeltas(std::vector<int> a, std::vector<int> b, std::vector<int> sizes);
    void prep(int src, int target);  
    void display(std::vector<int> l);  

    std::vector<int> forward, reverse;
    std::string netname;
    std::vector<int> netsize;
    std::map<std::string, std::string> policies;
    std::vector<std::vector<int> > across;
    //std::multimap<int, int> cache;  
    Layout* layout;
};
}
}

#endif
