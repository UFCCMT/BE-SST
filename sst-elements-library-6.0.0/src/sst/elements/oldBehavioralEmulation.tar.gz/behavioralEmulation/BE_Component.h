
#ifndef _BECOMPONENT_H
#define _BECOMPONENT_H

//#include <boost/python.hpp>
#include <assert.h>
#include <fstream>
#include <sst/core/component.h>
#include <sst/core/link.h>
#include "BE_CommEvent.h"
#include "Layout.h"
#include <Sim_Events.h>
#include <Process_Events.h>
#include <Executor.h>

namespace SST {
namespace BEComponent {

class beComponent : public SST::Component 
{
public:

    beComponent(SST::ComponentId_t id, SST::Params& params);

    ~beComponent();
    
    Layout* getLayoutInfo() { return layout; }

    int getGid() { return self_gid; }

    int getOrdinal() { return self_ordinal; }

    std::string getKind() { return self_kind; }

    std::string getOperations() { return operations; }

    std::string getRelations() { return relations; }

    std::string getProperties() { return properties; }
    

    void setup();

    virtual bool clockTic(SST::Cycle_t);

    void linkRecvEvent(Event *ev); 

    void build(Layout* layout, std::string file);

    std::vector<std::string> decode(std::string operand, std::string delimiter);

    bool running(bool flg);

    void run(double t_cap, time_t w_cap, int e_cap);

    void step(std::shared_ptr<Process> process);

    void tick(double eventTime, std::shared_ptr<simEvent> event, std::shared_ptr<Process> eventProcess);

    void walk(std::shared_ptr<Process> process);

    void handleEvents(std::shared_ptr<simEvent> event, std::shared_ptr<Process> eventProcess);

    void finish() {
      //Py_Finalize();
      //if(!waitQ.empty()) {printf("%d waiting", self_gid); std::cout<<" "<<self_kind<<"\n";}
      //if(!watchList.empty()) std::cout<<self_gid<<"--"<<self_kind<<" is pending on unsatisfied condition\n";
      //printf("Inside finish for %d\n", self_gid);
                //std::cout<<"\n"<< self_gid << "- " << "The self_time is "<<getCurrentSimTimeMicro()<<"\n";
                //std::cout<<"\n"<< self_gid << "- " << "The event queue is "<<"\n";
                //for(auto itr = previous.begin(); itr != previous.end(); itr++)
                    //std::cout<<(std::get<1>(*itr))->type<<" at "<<std::get<0>(*itr)<<"\n";
      //printf("Self_time is %f\n", self_time);

    }


private:

    beComponent();  // for serialization only
    beComponent(const beComponent&); // do not implement
    void operator=(const beComponent&); // do not implement
    
    beCommEvent* buildLinkEvent(double et, std::string type, int so, int tar, std::vector<int> list, int cid, std::string opp, std::string opid, std::string st);
    
    int self_gid, num_links, self_ordinal, self_clock;

    std::string sys_layout, self_kind, program_file, link_list, operations, relations, properties, mailboxes, attributes;

    std::shared_ptr<Executor> executor;

    std::shared_ptr<simManager> simulator;

    std::shared_ptr<Process> componentProcess;

    Layout* layout;

    double timeCap;
    time_t wallCap;
    int eventCap;

    double self_time;

    int key;

    std::queue<std::tuple<double, std::shared_ptr<timeoutEvent>, std::shared_ptr<Process>>> computeQ; 
   
    std::queue<std::tuple<std::shared_ptr<simEvent>, std::shared_ptr<Process>>> waitQ;

    std::queue<std::tuple<std::shared_ptr<simEvent>, std::shared_ptr<Process>>> routeQ;

    std::map<int, std::tuple<std::shared_ptr<conditionEvent>, std::shared_ptr<Process>>> watchList;

    std::map<int, std::queue<std::tuple<std::shared_ptr<simEvent>, std::shared_ptr<Process>>>> messageTable;

    std::map<int, std::queue<std::tuple<std::shared_ptr<simEvent>, std::shared_ptr<Process>>>> recvTable;

    std::list<std::tuple<double, std::shared_ptr<simEvent>>> eventList;

    std::map<int, SST::Link*> C_Link;

    SST::Link* selfEventLink;
    
};

} // namespace BEComponent
} // namespace SST

#endif /* _BECOMPONENT_H */
