#include <signal.h>
#include "Simulation_Manager.h"

using namespace SST;
using namespace SST::BEComponent;


std::tuple<std::vector<double>, std::queue<std::shared_ptr<eventTemplate>>> simManager::lookup(std::string operation, std::vector<int> inputs)
{

    std::queue<std::shared_ptr<eventTemplate>> templates;
    bool present = false;
    std::vector<double> outputs;
    std::string lookup_file; //lookup file name will be enclosed with " " - remove them

    std::tie(lookup_file, templates) = operations[operation];
        
    if(lookup_file != "None")
    { 
        /*if(self_gid == 7) {
            for(int j =0; j<inputs.size(); j++) std::cout<<inputs[j]<<" ";
            printf("\n");
        }*/

        lookup_cache = getCache();
    
        for(auto itr = lookup_cache.begin(); itr != lookup_cache.end(); itr++)
        {
            if(std::get<0>(itr->first) == lookup_file && vectorCheck(inputs, std::get<1>(itr->first))) {
                outputs = itr->second;
                present = true;
                break;
            }    
        }
      
        if(!present)
        {
            PyObject* inputList = vectorToList(inputs);
            PyObject* filename = PyString_FromString(lookup_file.c_str());
            PyObject* degree = PyFloat_FromDouble( (double) 1);
            PyObject* outputList = PyObject_CallFunctionObjArgs(myFunction, filename, inputList, degree, NULL);
                //PyObject* myValue = PyList_GetItem(outputList, 0);
                //double result = PyFloat_AsDouble(myValue);
            outputs = listToVector(outputList);
            lookup_cache[make_tuple(lookup_file, inputs)] = outputs;
            updateCache(lookup_cache);
        }
      
    } 
	
    return std::make_tuple (outputs, templates);

}


PyObject* simManager::vectorToList(std::vector<int> data){

  PyObject* listObj = PyList_New( data.size() );
	if (!listObj) throw std::runtime_error("Unable to allocate memory for Python list");
	for (int i = 0; i < data.size(); i++) {
		PyObject *num = PyFloat_FromDouble( (double) data[i]);
		if (!num) {
			Py_DECREF(listObj);
			throw std::runtime_error("Unable to allocate memory for Python list");
		}
		PyList_SET_ITEM(listObj, i, num);
	}
	return listObj;
}


std::vector<double> simManager::listToVector(PyObject* incoming){

	std::vector<double> data;

	if(PyList_Check(incoming))
	{
	    for(Py_ssize_t i = 0; i < PyList_Size(incoming); i++){
				PyObject *value = PyList_GetItem(incoming, i);
				data.push_back(PyFloat_AsDouble(value));
		}
	} 
	else
	{
		throw std::runtime_error("Passed PyObject pointer was not a list!");
		data.push_back(0.0);
	}
		
	return data;
	
}


bool simManager::vectorCheck(std::vector<int> list1, std::vector<int> list2){

    if(list1.size() == list2.size())
    {
        for(int i = 0; i < list1.size(); i++)
            if(list1[i] != list2[i]) return false;
    }
    else
        return false;
        
    return true;
    
}



int simManager::obtain(std::string property){  //generalised implementation reqd

    try
    {
        if(properties[property] == "True") return 1;
        else if(properties[property] == "False") return 0;
        else return stoi(properties[property]);
    }
    catch(...)
    {
        std::cout<<"Problem with the Property: "<<property<<"\n";
        throw std::runtime_error("Problem with the Property");       
    }

}
        

std::shared_ptr<Routine> simManager::call(int source_gid, int source_pid, int target_gid, std::string target, std::string operation, std::vector<int> inputs, std::string call_type){

    int targetGID;
    if(self_gid == source_gid) targetGID = relations[target];
    else targetGID = target_gid;
    std::vector<double> outputs;
    std::queue<std::shared_ptr<eventTemplate>> templates;

    if(targetGID == self_gid)
    {
        std::tie(outputs, templates) = lookup(operation, inputs);
        
        if(source_gid != self_gid && call_type == "blocking")
        {
            //std::cout<<"Call being serviced by "<<self_gid<<" for "<<source_gid;
            std::vector<int> source;
            source.push_back(source_gid);
            source.push_back(self_gid);
            templates.push(std::make_shared<ackTemplate>(source_pid, source, true));
        }

        auto routine = std::make_shared<Routine>(targetGID, hardware_state, inputs, outputs, templates);
        return routine;
    }

    else
    {
        templates.push(std::make_shared<callTemplate>(self_gid, source_pid, targetGID, target, operation, inputs, call_type, true));
        if(call_type == "blocking") templates.push(std::make_shared<waitTemplate>(true));
        auto routine = std::make_shared<Routine>(targetGID, hardware_state, inputs, outputs, templates);
        return routine;
    }

}


std::shared_ptr<Message> simManager::comm(int gid, int pid, std::string operation, int size, int target_rank, int tag, std::string comm_type){

    int source = self_ordinal; //layout->rordinals[executor->gid];
    //std::cout<<"Source: "<<source<<" and Target: "<<target_rank<<"\n";
    if (operation == "send")
    {
        std::vector<int> locations;// = router->path(source, target_rank);
        //router->clear();
        auto message = std::make_shared<Message>(gid, pid, source, target_rank, size, tag, locations, comm_type, hardware_state);

        //std::cout<<"Locations generated are ";
            
        return message;
    }

    else return NULL;

}


std::queue<std::shared_ptr<Process>> simManager::mailbox_routines (std::vector<int> gids, int pid, int source, int target, int size, int tag, std::string comm_type)
{

    std::vector<int>::iterator igid;
    std::vector<int> locations = gids;
    int i;
    std::string operation;
    bool onSource, onMiddle, onTarget; 
    std::vector<int> inputs;
    std::vector<double> outputs;
    std::queue<std::shared_ptr<eventTemplate>> templates;
    std::queue<std::shared_ptr<Process>> routines;

    for (i = 0, igid = gids.begin(); igid != gids.end(); ++i, ++igid)
    {
        if((*igid) == self_gid)
        {  
            std::tuple<bool, bool, bool> targets;
 
            std::tie(operation, targets) = mailboxes; // list of multiple operations? or just one per kind 
            std::tie(onSource, onMiddle, onTarget) = targets;

            if ((i == 0 && onSource) || (i == gids.size()-1 && onTarget) || (i < gids.size()-1 && onMiddle))
            {
                inputs = mailbox_function(source, target, size, tag);   
		std::tie(outputs, templates) = lookup(operation, inputs);
      
                if(i != gids.size()-1)
                    templates.push(std::make_shared<communicateTemplate>(pid, source, size, target, tag, locations, locations[i+1], comm_type, true));
                else if(comm_type == "blocking")
                    templates.push(std::make_shared<ackTemplate>(pid, locations, true));

		auto routine = std::make_shared<Routine>(self_gid, hardware_state, inputs, outputs, templates);
                routines.push(routine);		 
	    }
        }
 
    }
 
    return routines;

}


std::shared_ptr<Executor> simManager::prog(std::string filename) //check if correct
{

    auto executor = std::make_shared<Executor>(self_gid, giveExecutorId(), filename, std::shared_ptr<simManager>(this), hardware_state);
    return executor;
}


std::vector<std::string> simManager::decode(std::string operand, std::string delimiter)
{	

    size_t pos = 0;
    std::vector<std::string> operandList;
    ////std::cout<<operand<<std::endl;
    while((pos = operand.find(delimiter)) != std::string::npos){          
        ////std::cout<<operand<<std::endl;  
        operandList.push_back(operand.substr(0, pos));
        ////std::cout << operand.substr(0, pos) << std::endl;
        operand.erase(0, pos + delimiter.length());
    }
    operandList.push_back(operand);

    return operandList;
            
}


void simManager::buildInformation(std::string templates, std::string relation_info, std::string property_info, std::string mailbox_info)
{

    std::vector<std::string> list1, list2, list3, list4;

    /* Parse the template string to build the set of operations as specified in the configuration file*/
    if(templates.size() > 4)
        list1 = decode(templates.substr(1, templates.size()-4), "]), ");

    for(auto itr = list1.begin(); itr != list1.end(); itr++)
    {
        //std::cout<<"itr: "<<*itr<<"\n";
        list2 = decode(*itr, ": (");
        std::string opr, oprList, lookup_s, events_s;
 
        if(list2.size() == 2){
            opr = list2[0];
            oprList = list2[1];
        }

        list3 = decode(oprList, ", [");

        if(list3.size() == 2){
            lookup_s = list3[0];
            events_s = list3[1];
        }

        list4 = decode(events_s, ", ");

        std::queue<std::shared_ptr<eventTemplate>> op_template;

        for(auto itr1 = list4.begin(); itr1 != list4.end(); itr1++)
        {
            //std::cout<<"itr1: "<<*itr1<<"\n";
            std::vector<std::string> list5;

            if(itr1->size() > 2)
                list5 = decode(itr1->substr(1, itr1->size()-2), " ");

            op_template.push(buildTemplate(list5));

        }
        
        if(lookup_s != "None" && lookup_s.size() > 2) lookup_s = lookup_s.substr(1, lookup_s.size()-2);
        
        operations[opr.substr(1, opr.size()-2)] = std::tie(lookup_s, op_template);

    }

    
    std::vector<std::string> empty1, empty2, empty3;

    std::swap(list1, empty1);

    /* Parse the relation string to build the component relations as specified in the configuration file */
    if(relation_info.size() > 2)
        list1 = decode(relation_info.substr(1, relation_info.size()-2), ", "); 

    for(auto itr = list1.begin(); itr != list1.end(); itr++)
    {
        list2 = decode(*itr, ": ");   

        if(list2.size() == 2)
            relations[list2[0].substr(1, list2[0].size()-2)] = stoi(list2[1]);
    }


    std::swap(list1, empty2);
    
    /* Parse the property string to build the set of properties for the component as specified in the configuration file */
    if(property_info.size() > 2)
        list1 = decode(property_info.substr(1, property_info.size()-2), ", "); 

    for(auto itr = list1.begin(); itr != list1.end(); itr++)
    {
        list2 = decode(*itr, ": ");   

        if(list2.size() == 2)
            properties[list2[0].substr(1, list2[0].size()-2)] = list2[1];
    }


    std::swap(list1, empty3);

    /* Parse the mailbox string in order to build the component mailbox (set of operations and its parameters that need to be invoked in case of a message receive) */
    /* Assumes a single mailbox per component for now */ 
    std::string mailbox_operation;
    std::tuple<bool, bool, bool> mailbox_targets;

    if(mailbox_info.size() > 2)
        list1 = decode(mailbox_info.substr(2, mailbox_info.size()-5), ", [");

    if(list1.size() == 2) 
    {
        mailbox_operation = list1[0].substr(1, list1[0].size()-2);       
    
        list2 = decode(list1[1], "], (");

        if(list2.size() == 2) {
            mailboxList = decode(list2[0], ", ");
            list4 = decode(list2[1], ", ");
            bool s = stringToBool(list4[0]), m = stringToBool(list4[1]), d = stringToBool(list4[2]);
            mailbox_targets = std::tie(s, m, d);
        }
    }

    mailboxes = std::tie(mailbox_operation, mailbox_targets);

}


std::shared_ptr<eventTemplate> simManager::buildTemplate(std::vector<std::string> t_list)
{

    bool prov;
    std::string type;
    std::vector<std::string> list1;
    Procrastinator* container;

    if(t_list.back() == "True") prov = true;
    else prov = false;

    if(t_list[0] == "condition")
        if(t_list[3] == "True") t_list[3] = "1.0";
        else if(t_list[3] == "False") t_list[3] = "0.0";

    if(t_list[0] == "change")                  
        if(t_list[2] == "True") t_list[2] = "1.0";
        else if(t_list[2] == "False") t_list[2] = "0.0";

    
    if(t_list[0] == "condition") 
    {        
        list1 = decode(t_list[3], "::");
        if(!list1.empty()) std::tie(type, container) = value_find(list1);

        if(type == "double") return std::make_shared<conditionTemplate<double>>(t_list[1], t_list[2], stod(t_list[3]), "double", prov);
        else if(type == "procrastinator") return std::make_shared<conditionTemplate<Procrastinator*>>(t_list[1], t_list[2], container, "procrastinator", prov);
    }

    else if(t_list[0] == "change") 
    {
        list1 = decode(t_list[2], "::");
        if(!list1.empty()) std::tie(type, container) = value_find(list1);

        if(type == "double") return std::make_shared<changeTemplate<double>>(t_list[1], stod(t_list[2]), "double", prov);
        else if(type == "procrastinator") return std::make_shared<changeTemplate<Procrastinator*>>(t_list[1], container, "procrastinator", prov);
    }

    else if(t_list[0] == "timeout") 
    {
        list1 = decode(t_list[1], "::");
        if(!list1.empty()) std::tie(type, container) = value_find(list1);

        if(type == "double") return std::make_shared<timeoutTemplate<double>>(stod(t_list[1]), "double", prov);
        else if(type == "procrastinator") return std::make_shared<timeoutTemplate<Procrastinator*>>(container, "procrastinator", prov);
    }

    else if(t_list[0] == "receivewait")
    {
        return std::make_shared<recvWaitTemplate>(prov);
    }

    else if(t_list[0] == "receive")
    {
        return std::make_shared<recvTemplate>(prov);
    } 

    else return std::make_shared<timeoutTemplate<double>>(0, "none", false);

    return std::make_shared<timeoutTemplate<double>>(0, "none", false);

}


std::tuple<std::string, Procrastinator*> simManager::value_find(std::vector<std::string> list)
{
    try
    {
        double d = stod(list[0]);
        Procrastinator *p = NULL;
        return std::tie("double", p);
    }

    catch(...)
    {
       
        std::string math_operation;
        std::tuple<std::string, Procrastinator*> operandValue;

        if(list.size() > 2)
        {
            std::vector<std::string> subList = list;
            subList.erase(subList.begin(), subList.begin()+2); // remove the first 2 elements of the list - main procrastinator and the first operation
            operandValue = value_find(subList);  
            //if(self_gid == 42) std::cout<<std::get<0>(operandValue)<<" "<<std::get<1>(operandValue)->type<<"\n";          
            math_operation = list[1];
        } 

        std::vector<std::string> list1 = decode(list[0], "(");
        
        if(list1[0] == "Attribute"){
            attributeProcrastinator *a = new attributeProcrastinator(list1[1].substr(0, list1[1].size()-1));
            if(std::get<0>(operandValue) == "double") a = dynamic_cast<attributeProcrastinator *>(a->operate(math_operation, stod(list[2]), std::get<1>(operandValue)));
            else if(std::get<0>(operandValue) == "procrastinator") a = dynamic_cast<attributeProcrastinator *>(a->operate(math_operation, 0.0, std::get<1>(operandValue)));
            return std::tie("procrastinator", a);
        }
        else if(list1[0] == "Input"){
            inputProcrastinator *i = new inputProcrastinator(stod(list1[1].substr(0, list1[1].size()-1)));
            if(std::get<0>(operandValue) == "double") i = dynamic_cast<inputProcrastinator *>(i->operate(math_operation, stod(list[2]), std::get<1>(operandValue)));
            else if(std::get<0>(operandValue) == "procrastinator") i = dynamic_cast<inputProcrastinator *>(i->operate(math_operation, 0.0, std::get<1>(operandValue)));
            return std::tie("procrastinator", i);
        }
        else if(list1[0] == "Output"){
            outputProcrastinator *o = new outputProcrastinator(stod(list1[1].substr(0, list1[1].size()-1)));
            if(std::get<0>(operandValue) == "double") o = dynamic_cast<outputProcrastinator *>(o->operate(math_operation, stod(list[2]), std::get<1>(operandValue)));
            else if(std::get<0>(operandValue) == "procrastinator") o = dynamic_cast<outputProcrastinator *>(o->operate(math_operation, 0.0, std::get<1>(operandValue)));
            return std::tie("procrastinator", o);
        }
        else if(list1[0] == "Random"){
            randomProcrastinator *r = new randomProcrastinator(0);
            if(std::get<0>(operandValue) == "double") r = dynamic_cast<randomProcrastinator *>(r->operate(math_operation, stod(list[2]), std::get<1>(operandValue)));
            else if(std::get<0>(operandValue) == "procrastinator") r = dynamic_cast<randomProcrastinator *>(r->operate(math_operation, 0.0, std::get<1>(operandValue)));
            return std::tie("procrastinator", r);
        }
        else{
            Procrastinator *p = NULL;
            return std::tie("none", p);
        }

    }

}
