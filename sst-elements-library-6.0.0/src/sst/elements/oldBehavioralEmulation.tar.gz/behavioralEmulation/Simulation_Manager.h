#ifndef SIMULATION_MANAGER_H
#define	SIMULATION_MANAGER_H

#include <map>
#include <vector>
#include <queue>
#include <tuple>
#include <list>
#include <memory>
#include <boost/python.hpp>
#include <sst/core/event.h>
#include "Sim_Events.h"
#include "Process_Events.h"
#include "Event_Template.h"
#include "Process.h"
#include <Executor.h>
#include <Routine.h>
#include "Message.h"
#include "Layout.h"
#include "Router.h"
#include "Containers.h"

namespace SST {
namespace BEComponent {

class Executor;
class Message;

class simManager
{

public:
    simManager(int gid, std::string kind, int ordinal, std::string ops, std::string rels, 
               std::string props, std::string mbxes, Layout* lyt, PyObject* myFunc, 
               std::function<void(std::map<std::tuple<std::string, std::vector<int>>, std::vector<double>>)> updCache, 
               std::function<std::map<std::tuple<std::string, std::vector<int>>, std::vector<double>>()> gtCache)
    {
                executor_id = 0;
                self_gid = gid;
                self_kind = kind;
                self_ordinal = ordinal;
                layout = lyt;
                myFunction = myFunc;
                updateCache = updCache;
                getCache = gtCache;
                buildInformation(ops, rels, props, mbxes);

		std::map<std::string, std::string> policies; // default policies??
		policies["MESH"] = "first-to-last";
		policies["TORUS"] = "first-to-last";
		policies["TREE"] = "default";
		policies["CUBE"] = "first-to-last";		
		router = new Router(layout, policies);	
		
		hardware_state["usage"] = 0.0;
		hardware_state["waiting"] = 0.0;
		attributes[self_kind] = hardware_state; // do v need attributes? attributes are storing info about state of each component  
		                	
    }
    
    ~simManager(){}
    
    Layout* layout;

    Router* router;

    int self_gid, self_ordinal;

    PyObject* myFunction;

    int test;

    std::string self_kind;

    std::vector<std::string> mailboxList;

    std::map<std::string, std::string> programs;

    std::tuple<std::string, std::tuple<bool, bool, bool>> mailboxes; //check

    std::map<std::string, double> hardware_state;
    
    std::map<std::string, std::tuple<std::string, std::queue<std::shared_ptr<eventTemplate>>>> operations;

    std::map<std::string, int> relations;

    std::map<std::string, std::string> properties;

    std::map<std::string, std::map<std::string, double>> attributes; 

    std::map<std::tuple<std::string, std::vector<int>>, std::vector<double>> lookup_cache;
    // indicators
    
    
    int giveExecutorId() { return ++executor_id; }
    
    std::tuple<std::vector<double>, std::queue<std::shared_ptr<eventTemplate>>> lookup(std::string operation, std::vector<int> inputs);

    PyObject* vectorToList(std::vector<int> data);

    std::vector<double> listToVector(PyObject* incoming);

    bool vectorCheck(std::vector<int> list1, std::vector<int> list2);

    std::queue<std::shared_ptr<Process>> mailbox_routines (std::vector<int> gids, int pid, int source, int target, int size, int tag, std::string comm_type);

    int obtain(std::string property);

    void buildInformation(std::string templates, std::string relation_info, std::string properties_info, std::string mailboxes_info);

    std::shared_ptr<eventTemplate> buildTemplate(std::vector<std::string> t_list);

    std::tuple<std::string, Procrastinator*> value_find(std::vector<std::string> list);

    std::vector<std::string> decode(std::string operand, std::string delimiter);

    std::shared_ptr<Routine> call(int source_gid, int source_pid, int target_gid, std::string target, std::string operation, std::vector<int> inputs, std::string call_type);

    std::shared_ptr<Message> comm(int gid, int pid, std::string operation, int size, int target_rank, int tag, std::string comm_type);

    std::shared_ptr<Executor> prog(std::string filename);
    
    std::function<void(std::map<std::tuple<std::string, std::vector<int>>, std::vector<double>>)> updateCache;
  
    std::function<std::map<std::tuple<std::string, std::vector<int>>, std::vector<double>>()> getCache;

    bool stringToBool(std::string str) const {
        if(str == "True") return true;
        else return false;
    }

    std::vector<int> mailbox_function(int source, int target, int size, int tag) {
        std::vector<int> list;
        for(int i=0; i<mailboxList.size(); i++) {
            if(mailboxList[i] == "'source'") list.push_back(source);
            else if(mailboxList[i] == "'target'") list.push_back(target);
            else if(mailboxList[i] == "'size'") list.push_back(size);
            else if(mailboxList[i] == "'tag'") list.push_back(tag);
        }
        return list;
    }
 

private:
   
    int executor_id;

};  

                 
}
}

#endif	/* SIMULATOR_H */

