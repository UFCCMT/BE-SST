#ifndef ROUTINE_H
#define ROUTINE_H

#include <map>
#include <vector>
#include <queue>
#include <functional>
#include <memory>
#include "Sim_Events.h"
#include "Process_Events.h"
#include "Event_Template.h"
#include "Process.h"
#include <sst/core/event.h>
#include "Containers.h"
#include <boost/function.hpp>

namespace SST {
namespace BEComponent {

class eventTemplate;

class Routine : public Process{
public:
    explicit Routine(int g, std::map<std::string, double> s, std::vector<int> inp, std::vector<double> out, std::queue<std::shared_ptr<eventTemplate>> seq) : Process(){
        gid = g;	
	state = s;          
        input = inp;       
        output = out;      
        sequence = seq;    
        type = "Routine";
        init_check();
        event_template = NULL;
        //printf("creating routine\n");
	}
    
    ~Routine(){};

    std::shared_ptr<simEvent> run();

    std::tuple<std::vector<int>, std::vector<double>> getRoutineParams() {
        return std::tie(input, output);
    }


private:
    int gid, pid; // pid?
    //std::map<std::string, double> state;
    std::vector<int> input;
    std::vector<double> output; 
    std::queue<std::shared_ptr<eventTemplate>> sequence;
    std::shared_ptr<eventTemplate> event_template;
    
    std::map<std::string, boost::function<bool(double, double)>> check;
	
	void init_check(){
		check["=="] = std::equal_to<double>();
		check["!="] = std::equal_to<double>();
		check["<="] = std::less_equal<double>();
		check[">="] = std::greater_equal<double>();
		check["<"] = std::less<double>();
		check[">"] = std::greater<double>();
	}
	
    double find(Procrastinator* value);
	
    //template <class T1, class T2> T2 find(T1 value);
    
};

//template <class T2> T2 Routine::find<Procrastinator<int>, T2>(Procrastinator<int> value);

}
}
#endif
