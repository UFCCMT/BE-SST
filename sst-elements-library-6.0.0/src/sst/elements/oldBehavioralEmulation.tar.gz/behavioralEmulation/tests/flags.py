output_file = ''
system_config = 'vulcan-proper.py'
interpolation = ''
