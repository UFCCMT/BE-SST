# Automatically generated SST Python input
import sst
from simulator_build import Simulator

# Define SST core options
sst.setProgramOption("timebase", "1 ps")
#sst.setProgramOption("stopAtCycle", "25us")

# Obtain the simulation flags
try:
    execfile("flags.py")
except:
    print "Error with file flags.py"
    system_config = "Config file error"

sim = Simulator(system_config)

sim.build()

system_gids = sim.gids
system_kinds = sim.layout.kinds
system_edges = sim.layout.edges
system_cids = sim.layout.cids 
system_rordinals = sim.layout.rordinals
system_relations = sim.layout.relations
system_parents = sim.layout.parents
system_components = sim.designer.components
system_programs = sim.programs
system_operations = sim.operationDetails
system_properties = sim.designer.properties
system_tallies = sim.layout.tallies
system_indices = sim.layout.indices
system_mailboxes = sim.mailboxes
system_attributes = sim.attributes
 
root = sim.designer.system


layout = ""
i=0
with open('layoutfile', 'r') as fin:
    for line in fin:
        i=i+1
        layout = layout+line


# Define the simulation components
system_comps = []

for gid in system_gids:

    comp = sst.Component(str(gid), "behavioralEmulation.beComponent")
    system_comps.append(comp)


ic_links = {}
other_links = {}
root_links = []
other_relations = {}
component_links = {}
operations = {}
relations = {}
clock = 1000000

cores = 0
links = 0
memory = 0
containers = 0


# Define the simulation links
for gid in system_gids:

    parent = system_parents[gid]
    operations[gid] = {}
    relations[gid] = {}

    if system_kinds[gid] in system_operations: operations[gid] = system_operations[system_kinds[gid]]

    if gid in system_relations:
        relations[gid] = system_relations[gid]
        for component in system_relations[gid]:
            component_id = system_relations[gid][component]
            if component_id != gid:
                link = sst.Link("link"+str(gid)+' '+str(component_id))
                system_comps[gid].addLink(link, "Link "+str(component_id), "1ps")
                system_comps[component_id].addLink(link, "Link "+str(gid), "1ps")
                if gid in component_links: component_links[gid].append(component_id)
                else: component_links.update({gid: [component_id]})
                if component_id in other_links: other_links[component_id].append(gid)
                else: other_links.update({component_id: [gid]})


    for edge in system_edges[gid]:
        if edge:
            ic_gid = edge[-1]
            link = sst.Link("link"+str(gid)+' '+str(ic_gid))
            system_comps[gid].addLink(link, "Link "+str(ic_gid), "1ps")
            system_comps[ic_gid].addLink(link, "Link "+str(gid), "1ps")
            if gid in component_links: component_links[gid].append(ic_gid)
            else: component_links.update({gid: [ic_gid]})
            if ic_gid in ic_links: ic_links[ic_gid].append(gid)
            else: ic_links.update({ic_gid: [gid]})

    
    if(gid in component_links and parent != "null" and parent != 0):
        link = sst.Link("link"+str(gid)+' '+str(parent))
        system_comps[gid].addLink(link, "Link "+str(parent), "1ps")
        system_comps[parent].addLink(link, "Link "+str(gid), "1ps")
        component_links[gid].append(parent)
        component_links[parent].append(gid)


# Define the simulation parameters
for gid in system_gids:

    properties = {}
    attributes = []
    config_mailbox = []
    simulation_mailbox = []
    
    index =  (system_indices[gid]
              if gid in system_indices else None)
    
    for property_name in system_properties[system_kinds[gid]]:
        properties[property_name] = system_properties[system_kinds[gid]][property_name](gid, system_cids[gid], system_tallies[system_kinds[gid]], index)

    if system_kinds[gid] in system_attributes: attributes = system_attributes[system_kinds[gid]]  

    if system_kinds[gid] in system_mailboxes: config_mailbox = system_mailboxes[system_kinds[gid]]

    for entry in config_mailbox:
        simulation_mailbox.append((entry[0], entry[1]("source", "target", "size", "tag"), entry[2]))


    if system_kinds[gid] == root:
        pass

    elif gid not in component_links and gid in ic_links:
        links = links+1
        system_comps[gid].addParams({
          "System Layout" : """none""",
          "Component clock" : clock,
          "Component kind" : system_kinds[gid],
          "Component gid" : gid,
          "Component ordinal" : """-1""",
          "Attributes" : str(attributes),
          "Operations" : str(operations[gid]),
          "Relations" : str(relations[gid]),
          "Properties" : str(properties),
          "Mailboxes" : str(simulation_mailbox),
          "num_links" : str(len(ic_links[gid])),
          "Link list" : str(ic_links[gid]),
          "Software Program" : """none"""
        })
        #print 'Links for ', gid, ': ', str(ic_links[gid])

    elif gid not in component_links:   # other_links will throw key error if relations are not defined
        memory = memory+1
        system_comps[gid].addParams({
          "System Layout" : """none""",
          "Component clock" : clock,
          "Component kind" : system_kinds[gid],
          "Component gid" : gid,
          "Component ordinal" : """-1""",
          "Attributes" : str(attributes),
          "Operations" : str(operations[gid]),
          "Relations" : str(relations[gid]),
          "Properties" : str(properties),
          "Mailboxes" : str(simulation_mailbox),
          "num_links" : str(len(other_links[gid])),
          "Link list" : str(other_links[gid]),
          "Software Program" : """none"""
        })

    elif system_kinds[gid] not in system_programs:
        containers = containers + 1
        system_comps[gid].addParams({
          "System Layout" : """none""",
          "Component clock" : clock,
          "Component kind" : system_kinds[gid],
          "Component gid" : gid,
          "Component ordinal" : """-1""",
          "Attributes" : str(attributes),
          "Operations" : str(operations[gid]),
          "Relations" : str(relations[gid]),
          "Properties" : str(properties),
          "Mailboxes" : str(simulation_mailbox),
          "num_links" : str(len(component_links[gid])),
          "Link list" : str(component_links[gid]),
          "Software Program" : """none"""
        })
   
    else:
        cores = cores+1
        link = sst.Link("link"+str(gid)+" 0")
        system_comps[gid].addLink(link, "Link 0", "1ps")
        component_links[gid].append(0)
        system_comps[gid].addParams({
          "System Layout" : """none""",
          "Component clock" : clock,
          "Component kind" : system_kinds[gid],
          "Component gid" : gid,
          "Component ordinal" : system_rordinals[gid],
          "Attributes" : str(attributes),
          "Operations" : str(operations[gid]),
          "Relations" : str(relations[gid]),
          "Properties" : str(properties),
          "Mailboxes" : str(simulation_mailbox),
          "num_links" : str(len(component_links[gid])),
          "Link list" : str(component_links[gid]),
          "Software Program" : "Software/"+system_programs[system_kinds[gid]]
        })
        system_comps[0].addLink(link, "Link "+str(gid), "1ps")
        root_links.append(gid)
        #print 'Links for ', gid, ': ', str(component_links)


system_comps[0].addParams({
  "System Layout" : layout,
  "Component clock" : clock,
  "Component kind" : system_kinds[0],
  "Component gid" : """0""",
  "Component ordinal" : """-1""",
  "Attributes" : """[]""",
  "Operations" : """{}""",
  "Relations" : """{}""",
  "Properties" : """{}""",
  "Mailboxes" : """[]""",
  "num_links" : str(len(root_links)),
  "Link list" : str(root_links),
  "Software Program" : """none"""
})    

print "The number of components are:- \n", "1) Cores: ", cores, "\n2) Links: ", links, "\n3) Containers: ", containers, "\n4) Memory: ", memory

#link1 = sst.Link("link1")
#comp1.addLink(link1, "Link 1", "1ps")
#comp3.addLink(link1, "Link 1", "1ps")
#link1.connect( (comp1, "Link 1", "1ps"), (comp3, "Link 1", "1ps") )

#link2 = sst.Link("link2")
#comp2.addLink(link2, "Link 1", "1ps")
#comp3.addLink(link2, "Link 2", "1ps")
#link2.connect( (comp2, "Link 1", "1ps"), (comp3, "Link 2", "1ps") )


# End of generated output.
