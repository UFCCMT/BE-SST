#!/bin/bash

while getopts :c:o:i:v option
do
        case "${option}"
        in
                c)   SYSTEM_CONFIG=${OPTARG};
                     SYS_C_PRESENT=1;;
                o)   OUTPUT_FILE=${OPTARG};;
                i)   INTERPOLATION=${OPTARG};;
                v)   VERBOSE="TRUE";;
                ?)   ERROR="TRUE";;
        esac
done

if [[ $SYS_C_PRESENT != 1 ]]
then
	echo "Missing flag '-c'!! Please specify a valid System configuration file using -c"
        exit
fi

echo "output_file = '$OUTPUT_FILE'" > "flags.py"
echo "system_config = '$SYSTEM_CONFIG'" >> "flags.py"
echo "interpolation = '$INTERPOLATION'" >> "flags.py"

if [[ $VERBOSE = "TRUE" ]]
then
	mpirun -np 1 sst test_beComponent.py -v
else
	mpirun -np 1 sst test_beComponent.py
fi

