#include "sst_config.h"
#include "BE_Component.h"
#include "Process.h"
#include "Routine.h"
#include "Message.h"
#include "Simulation_Manager.h"
#include "Router.h"
#include <typeinfo>
#include <functional>
#include <ctime>
#include "sst/core/event.h"

using namespace SST;
using namespace SST::BEComponent;

beComponent::beComponent(ComponentId_t id, Params& params) :
  Component(id) 
{
   //printf("Inside the SST component constructor \n");
   bool found;

   self_gid = params.find<int64_t>("Component gid", 0, found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter gid\n");
    }

   if( self_gid == 0) std::cout<<"STARTED LAYOUT BUILD!!!\n";

   sys_layout = params.find<std::string>("System Layout", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter layout\n");
    }

   self_clock = params.find<int64_t>("Component clock", 0, found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter clock\n");
    } 

   self_kind = params.find<std::string>("Component kind", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter kind\n");
    }

   self_ordinal = params.find<int64_t>("Component ordinal", 0, found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter ordinal\n");
    }

   attributes = params.find<std::string>("Attributes", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter Attributes\n");
    }

   operations = params.find<std::string>("Operations", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter operations\n");
    }

   relations = params.find<std::string>("Relations", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter relations\n");
    }

   properties = params.find<std::string>("Properties", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter properties\n");
    }

   mailboxes = params.find<std::string>("Mailboxes", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter mailboxes\n");
    }

   num_links = params.find<int64_t>("num_links", 0, found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter num_links\n");
    }

   link_list = params.find<std::string>("Link list", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter link list\n");
    }

   program_file = params.find<std::string>("Software Program", "none", found);
    if (!found) {
        Simulation::getSimulation()->getSimulationOutput().fatal(CALL_INFO, -1,"couldn't find parameter Program\n");
    }

    self_time = 0.0;
    key = 0;
    componentProcess = std::make_shared<Process>();
   
    /* Configure the self link for computation events in each Component */
    selfEventLink = configureSelfLink("Selflink", new Event::Handler<beComponent>(this, &beComponent::linkRecvEvent));

    /* register the component clock */
    registerClock(std::to_string(self_clock)+"Hz", new Clock::Handler<beComponent>(this, 
                  &beComponent::clockTic));

    /* Build the layout structure in the Root Component */
    layout = new Layout();

    if( self_gid == 0){ 
      build(layout, sys_layout);
      std::cout<<"LAYOUT BUILD OVER!!!\n";
      } //layout->build(p1);

}


beComponent::~beComponent() 
{

}


beComponent::beComponent() : Component(-1)
{
    // for serialization only
}


void beComponent::setup()
{

    Py_Initialize();
    PyRun_SimpleString("import sys");
    //PyRun_SimpleString("sys.path.append(\"/home/ajay/scratch/src/sst-elements-library-6.0.0/src/sst/elements/behavioralEmulatio\")");
    PyObject* myModuleString = PyString_FromString((char*)"lookup");
    PyObject* myModule = PyImport_Import(myModuleString);
    PyObject* myFunction = PyObject_GetAttrString(myModule,(char*)"lookupValue");
    std::function<void(std::map<std::tuple<std::string, std::vector<int>>, std::vector<double>>)> updateCache = updateGlobalLookupCache;
    std::function<std::map<std::tuple<std::string, std::vector<int>>, std::vector<double>>()> getCache = getGlobalLookupCache;
    
    std::shared_ptr<simManager> sim = std::make_shared<simManager>(self_gid, self_kind, self_ordinal, operations, 
                                                                   relations, properties, mailboxes, layout, 
                                                                   myFunction, updateCache, getCache);

    simulator = sim;

    // configure out links
    std::vector<std::string> link_gids;
    int l_gid;
    link_gids = decode(link_list.substr(1, link_list.size()-2), ", ");

    for(int i = 0; i < num_links; i++){
        l_gid = stoi(link_gids[i]);
        C_Link[l_gid] = configureLink("Link "+link_gids[i], new Event::Handler<beComponent>(this, &beComponent::linkRecvEvent));
        assert(C_Link[l_gid]);
    }

    // Set up executor process if there is an application program to be run
    if(program_file != "none")
    {

      // tell the simulator not to end without us if component has an executor process
      primaryComponentDoNotEndSim();
      std::shared_ptr<Executor> Exe = std::make_shared<Executor>(self_gid, simulator->giveExecutorId(), program_file, simulator, simulator->hardware_state);
      executor = Exe;
      componentProcess->append(executor);

    }

    else
    {
     
      componentProcess->type = "Master Wait Process";
      
    }

    run(0, 0, 0);    

}


std::vector<std::string> beComponent::decode(std::string operand, std::string delimiter)
{	

    size_t pos = 0;
    std::vector<std::string> operandList;

    while((pos = operand.find(delimiter)) != std::string::npos){           
        operandList.push_back(operand.substr(0, pos));
        operand.erase(0, pos + delimiter.length());
    }
    operandList.push_back(operand);

    return operandList;
            
}


void beComponent::build(Layout* layout, std::string file)
{
    
    //if( self_gid > 0 ) std::cout<<"Anndddd\n";
    std::vector<std::string> list1; 
    

    list1 = decode(file, "\n");
    
    for(int i=0; i < 12; i++){

        ////printf("loop iteration %d\n", i);
        std::vector<std::string> list2, list3, list4, list5;

        if(i==2 || i==4){

            switch(i){
     
                case 2: list2 = decode(list1[i].substr(3, list1[i].size()-6), "]], [[");
                        for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++)
                        {
                            std::string temp1 = *itr1;
                            std::vector<std::vector<int>> sublist1;
                            list3 = decode(temp1, "], [");
                            for(auto itr2 = list3.begin(); itr2 != list3.end(); itr2++){
                                std::string temp2 = *itr2;
                                std::vector<int> sublist2;
                                list4 = decode(temp2, ", ");
                                for(auto itr3 = list4.begin(); itr3 != list4.end(); itr3++)
                                    if(*itr3 != "")
                                      sublist2.push_back(stoi(*itr3));                                
                                
                                sublist1.push_back(sublist2);
                            }                                
                            layout->edges.push_back(sublist1);
                               
                        }
                        break;

                case 4: list2 = decode(list1[i].substr(2, list1[i].size()-4), "], [");
                        for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++)
                        {
                            std::string temp1 = *itr1;
                            std::vector<int> sublist1;
                            list3 = decode(temp1, ", ");
                            for(auto itr2 = list3.begin(); itr2 != list3.end(); itr2++)
                                if(*itr2 != "")
                                  sublist1.push_back(stoi(*itr2));                                
                            layout->children.push_back(sublist1);
                               
                        }
                        break;
           
            }


        } 

        else if(i==0 || i==1 || i==3){

            list2 = decode(list1[i].substr(1, list1[i].size()-2), ", "); 

            switch(i){

                case 0: for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++){
                            if(*itr1 != "")
                              layout->cid.push_back(stoi(*itr1));
                        }
                        break;

                case 1: for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++){
                            std::string temp1 = *itr1;
                            if(*itr1 != "")
                              layout->kinds.push_back(temp1.substr(1, temp1.size()-2));
                        }
                        break;

                case 3: for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++){
                            if(*itr1 == "null")
                              layout->parents.push_back(-1);
                            else if(*itr1 != "")
                              layout->parents.push_back(stoi(*itr1));
                        }
                        break;
 
            }
      
        }    

        else if(i==6 || i==9 || i==10){

            list2 = decode(list1[i].substr(1, list1[i].size()-2), ", ");
            
            switch(i){

                case 6: for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++)
                        {
                            std::string temp1 = *itr1;
                            std::string key = "", value = "";
                            list3 = decode(temp1, ": ");
                            if(list3[0].size() > 2)
                                key = list3[0].substr(1, list3[0].size()-2);
                            if(list3.size() > 1)
                                value = list3[1].substr(1, list3[1].size()-2);
                            if(key != "")
                              layout->netnames[stoi(key)] = value;       
                        }
                        break;

                case 9: for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++)
                        {
                            std::string temp1 = *itr1;
                            std::string key = "", value = "";
                            list3 = decode(temp1, ": ");
                            if(list3[0].size() > 2)
                                key = list3[0].substr(1, list3[0].size()-2);
                            if(list3.size() > 1)
                                value = list3[1];
                            if(key != "" && value != "")
                              layout->ordinals[stoi(key)] = stoi(value);     
                        }
                        break;

                case 10: for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++)
                        {
                            std::string temp1 = *itr1;
                            std::string key = "", value = "";
                            list3 = decode(temp1, ": ");
                            if(list3[0].size() > 2)
                                key = list3[0].substr(1, list3[0].size()-2);
                            if(list3.size() > 1)
                                value = list3[1];
                            if(key != "" && value != "")
                              layout->rordinals[stoi(key)] = stoi(value);       
                        }
                        break;
 
            }           

        } 

        else if(i==8){

            list2 = decode(list1[i].substr(1, list1[i].size()-3), "}, ");

            for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++){

                std::string temp1 = *itr1;
                list3 = decode(temp1, ": {");
                if(list3.size() > 1)
                    list4 = decode(list3[1], ", ");
                std::map<std::string, int> submap;

                for(auto itr2 = list4.begin(); itr2 != list4.end(); itr2++){
                    std::string temp2 = *itr2;
                    std::string key = "", value = "";
                    list5 = decode(temp2, ": ");
                    if(list5[0].size() > 2)
                        key = list5[0].substr(1, list5[0].size()-2);
                    if(list5.size() > 1)
                        value = list5[1];
                    if(value != "")
                      submap[key] = stoi(value); 
                }

                std::string pkey = "";
                if(list3[0].size() > 2)
                    pkey = list3[0].substr(1, list3[0].size()-2);
                if(pkey != "")
                  layout->relations[stoi(pkey)] = submap;

            }


        }

        else{

            list2 = decode(list1[i].substr(1, list1[i].size()-3), "], ");

            for(auto itr1 = list2.begin(); itr1 != list2.end(); itr1++){

                std::string temp1 = *itr1;
                std::string pkey = "";

                list3 = decode(temp1, ": [");

                if(list3[0].size() > 2)
                    pkey = list3[0].substr(1, list3[0].size()-2);
                if(list3.size() > 1)
                    list4 = decode(list3[1], ", ");

                std::vector<int> sublist;

                for(auto itr2 = list4.begin(); itr2 != list4.end(); itr2++){
                    if(*itr2 != "")
                      sublist.push_back(stoi(*itr2)); 
                }


                switch(i){

                  case 5: if(pkey != "")
                            layout->indices[stoi(pkey)] = sublist;
                          break;

                  case 7: if(pkey != "")
                            layout->netsizes[stoi(pkey)] = sublist;
                          break;

                  case 11: if(pkey != "")
                           layout->subordinals[stoi(pkey)] = sublist;
                           break;
 
                }

            }           

        }

    }
 
}


beCommEvent* beComponent::buildLinkEvent(double et, std::string type, int so, int tar, std::vector<int> list, int cid, std::string opp, std::string opid, std::string st){

    beCommEvent* bev = new beCommEvent();
    bev->eventTime = et;
    bev->type = type;
    bev->source = so;
    bev->target = tar;
    bev->list = list;
    bev->comp_id = cid;
    bev->op_param = opp;
    bev->op_id = opid;
    bev->sub_type = st;
    
    return bev;
    
}


void beComponent::step(std::shared_ptr<Process> process){


    //if( self_gid > 0 ) std::cout << self_gid << "- " << "Stepping through " << process->type << std::endl; 
    std::shared_ptr<simEvent> event = process->run();
 

    if (event != nullptr)
    {
        std::string event_type = event->type;
        //if( self_gid > 0 ) std::cout << self_gid << "- " << event_type << " event returned" << std::endl;	
	double delay;
	
	if (event_type == "timeout")
        {
            auto ev = std::dynamic_pointer_cast<timeoutEvent>(event);	
            //delay = ev->value*self_clock;
            delay = ev->value;
	}
	else
            delay = 0;
			
	double eventTime = self_time + delay;		
		
	if (event_type == "condition")
        {
	    auto ev = std::dynamic_pointer_cast<conditionEvent>(event);
            double value = simulator->hardware_state[ev->attribute];//ev->state[ev->attribute];

            if (ev->conditionFunction(value, ev->value))
            {
                //if( self_gid > 0 ) std::cout << self_gid << "- " << "Condition satisfied" << std::endl;
                tick(eventTime, ev, process);
            }
            else
            {
                //if( self_gid > 0 ) std::cout << self_gid << "- " << "Condition not satisfied---notifying the necessary components" << std::endl;
	        watchList[key] = make_tuple(ev, process);//do we need unique id for object?
                key++;
            }

        }

        else if (event_type == "wait")
        {
            auto ev = std::dynamic_pointer_cast<waitEvent>(event);
            waitQ.push(std::make_tuple(ev, process));//?????waiting[eventTimme]
        }

        else if (event_type == "route")
        {
            auto route_ev = std::dynamic_pointer_cast<routeEvent>(event);
            beCommEvent *bev = new beCommEvent();
            bev = buildLinkEvent(self_time, "route", route_ev->source, route_ev->target, route_ev->locations, route_ev->gid, "", std::to_string(route_ev->pid), "");
            routeQ.push(std::make_tuple(route_ev, process));
            //if( self_gid > 0 ) std::cout<<"source: "<<route_ev->source<<" and target: "<<route_ev->target<<" and gid: "<< route_ev->gid<<"\n";
            C_Link[0]->send(bev);
        }	

        else if (event_type == "receiveWait")
        {
            auto ev = std::dynamic_pointer_cast<recvWaitEvent>(event);
            bool present = false;
            std::shared_ptr<Routine> routine = std::dynamic_pointer_cast<Routine>(process);

            int msg_source = std::get<0>(routine->getRoutineParams())[1];

            for(auto itr = messageTable.begin(); itr != messageTable.end(); itr++) {

                if (msg_source == itr->first && !((itr->second).empty())) {
                    std::shared_ptr<Process> mprocess;
                    std::shared_ptr<simEvent> mevent;
                    std::tie(mevent, mprocess) = (itr->second).front();
                    (itr->second).pop();
                    tick(self_time, mevent, mprocess);
                    tick(self_time, ev, process);
                    present = true;
                }

            }

            if(!present) (recvTable[msg_source]).push(std::tie(ev, process));
             
        }

        else if (event_type == "receive")
        {
            auto ev = std::dynamic_pointer_cast<recvEvent>(event);
            bool present = false;
            std::shared_ptr<Routine> routine = std::dynamic_pointer_cast<Routine>(process);

            if((std::get<0>(routine->getRoutineParams())).empty()) 
                throw std::runtime_error("Receive/unwait expecting the message source as input!! (Add source to the lambda function of unwait operation)");

            int msg_source = std::get<0>(routine->getRoutineParams())[0];

            for(auto itr = recvTable.begin(); itr != recvTable.end(); itr++) {

                if (msg_source == itr->first && !((itr->second).empty())) {
                    std::shared_ptr<Process> rprocess;
                    std::shared_ptr<simEvent> revent;
                    std::tie(revent, rprocess) = (itr->second).front();
                    (itr->second).pop();
                    tick(self_time, revent, rprocess);
                    tick(self_time, ev, process);
                    present = true;
                }

            }

            if(!present) (messageTable[msg_source]).push(std::tie(ev, process));
             
        }			

	else if (event_type != "timeout")
        {		
            tick(eventTime, event, process);
	}

	else
        {
            auto ev = std::dynamic_pointer_cast<timeoutEvent>(event);
            //upcoming.push(std::make_tuple(eventTime, ev, process));
            computeQ.push(std::make_tuple(eventTime, ev, process));
            //upcoming.pop();
            std::vector<int> empty;
            beCommEvent *bev = new beCommEvent();
            bev = buildLinkEvent(eventTime, ev->type, -1, -1, empty, -1, "", "", "");
            selfEventLink->send(ev->value*self_clock, bev);
	}

    }

    else
    {
        //if( self_gid > 0 ) std::cout<<"Event in this process is now null \n";
        process->selfDelete();
  
	if (process->parent->children.empty())
	    step(process->parent);
	
	process->parent = nullptr;

    }

}

void beComponent::tick(double eventTime, std::shared_ptr<simEvent> event, std::shared_ptr<Process> eventProcess){
	

        //if( self_gid > 0 ) std::cout << self_gid << "- " << "Inside tick for the event " << event->type << std::endl;

        eventProcess->state = simulator->hardware_state;
	//self_time = eventTime;

        handleEvents(event, eventProcess); 
	std::tuple<double, std::shared_ptr<simEvent>> previous_set = std::make_tuple(eventTime, event);
	eventList.push_back(previous_set);
	
	if (eventProcess->children.empty() && eventProcess->parent != NULL){
		step(eventProcess);
	}
}

void beComponent::walk(std::shared_ptr<Process> process){ 

        std::stack<std::shared_ptr<Process>> children_q = process->children; 

	if (!children_q.empty()){
		while(!children_q.empty()){ // for loop might be necessary
			walk(children_q.top());
                        children_q.pop();
		}
	}
	else
		step(process);
}


void beComponent::run(double t_cap=0.0, time_t w_cap=0.0, int e_cap=0)
{

	timeCap = t_cap;
	wallCap = w_cap;
	eventCap = e_cap;
	//self_time = 0.0;
	
	walk(componentProcess);	
  
}


/* Does nothing during a clock tick as it is discrete event simulation */
bool beComponent::clockTic( Cycle_t )
{
       return false;                              
}


// incoming messages are scanned and deleted
void beComponent::linkRecvEvent(Event *ev) 
{
    //if( self_gid > 0 ) std::cout<<"Event received in component "<<self_gid<<"--"<<self_kind<<"!\n";

    beCommEvent *link_event = dynamic_cast<beCommEvent*>(ev);

    //if( self_gid > 0 ) std::cout<<"It is "<<link_event->type<<"\n";

    if (link_event)
    {

        self_time = link_event->eventTime;        

        if(link_event->type == "timeout")
        {
            std::tuple<double, std::shared_ptr<timeoutEvent>, std::shared_ptr<Process>> entry = computeQ.front(); 
            //double eventTime = std::get<0>(entry);
	    std::shared_ptr<simEvent> event = std::get<1>(entry);
	    std::shared_ptr<Process> eventProcess = std::get<2>(entry);
            computeQ.pop();
            tick(self_time, event, eventProcess);
            delete link_event;

        }

        else if(link_event->type == "communicate")
        {

            //auto comm_ev = std::dynamic_pointer_cast<commEvent>(link_event->event);
            std::vector<int> locations = link_event->list;
            std::queue<std::shared_ptr<Process>> routines;

            //if( self_gid > 0 ) std::cout<<"Event revd from "<<locations[0]<<"\n";

            routines = simulator->mailbox_routines(locations, link_event->comp_id, link_event->source, link_event->target, stoi(link_event->op_param), stoi(link_event->op_id), link_event->sub_type);
            if (!routines.empty())
            {
                std::shared_ptr<simEvent> routine_event = std::make_shared<subprocessEvent>(routines);
                tick(link_event->eventTime, routine_event, componentProcess);

            }
            else
            {
                for(int j = 0; j < locations.size()-1; j++){  //size()-1 because destination must not send anything
                    if( self_gid == locations[j]){
                        int next_hop = locations[j+1];
                        //if( self_gid > 0 ) printf("Not doing anything in %d. Forwarding the message to the next component %d\n", self_gid, next_hop);
                        beCommEvent *bev = new beCommEvent();
                        bev = buildLinkEvent(self_time, link_event->type, link_event->source, link_event->target, link_event->list, 
                                            link_event->comp_id, link_event->op_param, link_event->op_id, link_event->sub_type);
                        if(next_hop >= 0) C_Link[next_hop]->send(bev);
                        //if( self_gid > 0 ) printf("event sent\n");
                        break;
                    }
                }    
      
                if (self_gid == locations[locations.size()-1] && link_event->sub_type == "blocking")  //destination component creating acknowledge event if it is a blocking communication
                {
                    int nxt_hop = -1;
                    //printf("Destination Component %d preparing to acknowledge reception\n", self_gid); 

                    if(locations.size() > 1) nxt_hop = locations[locations.size()-2]; // This is not correct. Look into it!!
                    else if(locations.size() == 1) nxt_hop = locations[0];

                    beCommEvent *bev = new beCommEvent();
                    bev = buildLinkEvent(self_time, "acknowledge", -1, -1, link_event->list, 
                                         link_event->comp_id, "", "", "");

                    if(nxt_hop == self_gid) selfEventLink->send(bev);
                    else if(nxt_hop >= 0) C_Link[nxt_hop]->send(bev);
                }

            }

            delete link_event;                   
          
        }

        else if(link_event->type == "acknowledge")  // acknowledge after the destination completes its routine?
        {

            //auto ack_ev = std::dynamic_pointer_cast<ackEvent>(link_event->event);
            std::vector<int> locations = link_event->list;

            for(int j = locations.size()-1; j > 0; j--){
                if( self_gid == locations[j]){
                    int next_hop = locations[j-1];
                    beCommEvent *bev = new beCommEvent();
                    bev = buildLinkEvent(self_time, link_event->type, -1, -1, link_event->list, 
                                         link_event->comp_id, "", "", "");
                    //bev->event = ack_ev;
                    //bev->eventTime = self_time;
                    if(next_hop >= 0) C_Link[next_hop]->send(bev);
                    break;
                }
            }

            if (self_gid == locations[0] && !waitQ.empty()){
                //printf("Blocking Completion initiated by %d is complete\n", self_gid);
	        std::tuple<std::shared_ptr<simEvent>, std::shared_ptr<Process>> entry = waitQ.front();      //Change waitQ and acknowledge event to support process id
	        std::shared_ptr<simEvent> event;
	        std::shared_ptr<Process> eventProcess;
	        event = std::get<0>(entry);
	        eventProcess = std::get<1>(entry);
                waitQ.pop();
                //if( self_gid > 0 ) std::cout<<"Component "<<self_gid<<" received ack from "<<locations.back()<<" for "<<eventProcess->type<<"\n";
                tick(self_time, event, eventProcess); 
            }

            delete link_event;                

        }   

        else if(link_event->type == "route")
        {

            //auto route_ev = std::dynamic_pointer_cast<routeEvent>(link_event->event);
            //if( self_gid > 0 ) std::cout<<"this component received route "<<self_gid<<" from "<<link_event->comp_id<<"\n";

            if( self_gid == 0){
                std::vector<int> locations = simulator->router->path(link_event->source, link_event->target);
                simulator->router->clear();
       
                beCommEvent *bev = new beCommEvent();
                bev = buildLinkEvent(self_time, link_event->type, link_event->source, link_event->target, locations, 
                                     link_event->comp_id, link_event->op_param, link_event->op_id, link_event->sub_type);

                C_Link[link_event->comp_id]->send(bev);
            }

            else if( self_gid == link_event->comp_id){
                std::shared_ptr<Message> messageProcess; 
                std::tuple<std::shared_ptr<simEvent>, std::shared_ptr<Process>> entry = routeQ.front();
	        std::shared_ptr<simEvent> event;
	        event = std::get<0>(entry);
	        messageProcess = std::dynamic_pointer_cast<Message>(std::get<1>(entry));
                routeQ.pop(); 
                messageProcess->locations = link_event->list;
                //if( self_gid > 0 ) std::cout<<"Locations are: ";
                //if( self_gid > 0 ) for(int i=0; i<(link_event->list).size(); i++) std::cout<<(link_event->list)[i]<<" ";
                tick(self_time, event, messageProcess);
            }
                              
            delete link_event;

        }      

        else if(link_event->type == "call")
        {
            //if( self_gid > 0 ) std::cout<<"Event received in component "<<self_gid<<"--"<<self_kind<<"!\n";
            //auto call_ev = std::dynamic_pointer_cast<callEvent>(link_event->event);
            //if( self_gid > 0 ) std::cout<<"called by "<<link_event->source<<" for "<<link_event->op_id<<"\n";
            std::queue<std::shared_ptr<Process>> routine_queue;
            auto routine = simulator->call(link_event->source, link_event->comp_id, link_event->target, link_event->op_param, link_event->op_id, link_event->list, link_event->sub_type);
    	    routine_queue.push(routine);

    	    std::shared_ptr<simEvent> routine_event = std::make_shared<subprocessEvent>(routine_queue);
            tick(self_time, routine_event, componentProcess);
                              
            delete link_event;

        }      


    }   
    else 
    {
        throw std::runtime_error("Error! Bad Event Type!\n");//printf("Error! Bad Event Type!\n");
    }

}


void beComponent::handleEvents(std::shared_ptr<simEvent> event, std::shared_ptr<Process> eventProcess){

	std::string event_type = event->type;

	if (event_type == "change"){

             auto ev = std::dynamic_pointer_cast<changeEvent>(event);
             ev->state[ev->attribute] = ev->value;
             simulator->hardware_state[ev->attribute] = ev->value;
             //if( self_gid > 0 ) printf("Handling change event\n");
             //if( self_gid > 0 ) std::cout<<"Watchlist length is "<<watchList.size()<<"\n";
             bool process_ready = false;
             std::shared_ptr<conditionEvent> cond_event;
             std::shared_ptr<Process> cond_process;

             for (auto itr = watchList.begin(); itr != watchList.end(); itr++)         //Might have bugs...check!!!
             {         
                 cond_event = std::get<0>(itr->second);
                 cond_process = std::get<1>(itr->second);
                 if(cond_event->conditionFunction(simulator->hardware_state[cond_event->attribute], cond_event->value))
                 {
                     watchList.erase(itr);
                     process_ready = true;
                     //if( self_gid > 0 ) std::cout<<"Executing one waiting routine process from the watchList!!\n";
                     break;
                 }

             }
             
             if(process_ready == true) tick(self_time, cond_event, cond_process);
          
	}
	else if (event_type == "timeout"){
	        //if( self_gid > 0 ) printf("Handling timeout event\n");
	}
	else if (event_type == "condition"){
	        //if( self_gid > 0 ) printf("Handling condition event\n");
                
	}
	else if (event_type == "communicate"){

                auto comm_event = std::dynamic_pointer_cast<commEvent>(event);
                int next_hop = comm_event->next_hop;
                //if( self_gid > 0 ) printf("Forwarding the message from %d to the next component %d\n", self_gid, next_hop);
                beCommEvent *bev = new beCommEvent();
                bev = buildLinkEvent(self_time, comm_event->type, comm_event->source, comm_event->ranks, comm_event->locations, comm_event->pid, 
                                     std::to_string(comm_event->size), std::to_string(comm_event->tag), comm_event->comm_type);
                //bev->event = event;
                //bev->eventTime = self_time;
                if(next_hop >= 0) C_Link[next_hop]->send(bev);
                
	}
	else if (event_type == "initiate communication"){

	        //if( self_gid > 0 ) printf("Handling communication initiation in component %d\n", self_gid);
                auto messageProcess = std::dynamic_pointer_cast<Message>(eventProcess);
                auto comm_event = std::dynamic_pointer_cast<commEvent>(event);
                comm_event->locations = messageProcess->locations;
                //comm_event->type = "communicate";
                beCommEvent *bev = new beCommEvent();
                bev = buildLinkEvent(self_time, "communicate", comm_event->source, comm_event->ranks, comm_event->locations, comm_event->pid, 
                                     std::to_string(comm_event->size), std::to_string(comm_event->tag), comm_event->comm_type);
                //bev->event = comm_event;
                //bev->eventTime = self_time;
                selfEventLink->send(bev);
                
	}
	else if (event_type == "call"){

                auto call_event = std::dynamic_pointer_cast<callEvent>(event);
                beCommEvent *bev = new beCommEvent();
                bev = buildLinkEvent(self_time, call_event->type, call_event->source_gid, call_event->target_gid, call_event->inputs, call_event->source_pid, 
                                     call_event->target_family, call_event->operation, call_event->call_type);
                int target = call_event->target_gid;
                //bev->event = call_event;
                //bev->eventTime = self_time;
                if(target >= 0) C_Link[target]->send(bev);
                //if( self_gid > 0 ) std::cout<<"Calling the component "<<target<<"\n";
                
	}
	else if (event_type == "acknowledge"){

                auto ack_ev = std::dynamic_pointer_cast<ackEvent>(event);
                std::vector<int> locations = ack_ev->locations;
                int pid = ack_ev->pid;
                int nxt_hop = -1;

                if(locations.size() > 1) nxt_hop = locations[locations.size()-2]; // This is not correct-sort of a hack for the issue of a single component in route path. Look into it!!
                else if(locations.size() == 1) nxt_hop = locations[0];

                beCommEvent *bev = new beCommEvent();
                bev = buildLinkEvent(self_time, "acknowledge", -1, -1, locations, pid, "", "", "");

                //if( self_gid > 0 ) std::cout<<"sending ack to "<<nxt_hop<<" from "<<self_gid<<"\n";
                if(nxt_hop == self_gid) selfEventLink->send(bev);
                else if(nxt_hop >= 0) C_Link[nxt_hop]->send(bev);
                
	}
	else if (event_type == "subprocess"){

		auto ev = std::dynamic_pointer_cast<subprocessEvent>(event);
                //if( self_gid > 0 ) printf("Handling subprocess event\n");
		while (!ev->processes.empty()){                      //for loop might be neccessary!
			eventProcess->append(ev->processes.front()); //what if there are more than one routines in the sub process event 		
			step(ev->processes.front());
			ev->processes.pop(); 
		}

	}
	else if (event_type == "autoprocess"){

		auto ev = std::dynamic_pointer_cast<autoprocessEvent>(event);
                //if( self_gid > 0 ) printf("Handling autoprocess event\n");
		while (!ev->processes.empty()){
			componentProcess->append(ev->processes.front());
			step(ev->processes.front());
			ev->processes.pop();
		}
	}
	else if (event_type == "wait"){
	    //if( self_gid > 0 ) printf("Handling wait event\n");
	}
	else if (event_type == "terminate"){
            //if( self_gid > 0 ) printf("handling terminate event\n");
	    //if( self_gid > 0 ) printf("Self_time for %d is %f\n", self_gid, self_time);
            //if( self_gid > 0 ) printf("%d terminating\n", self_gid);
            primaryComponentOKToEndSim();
	}

}



